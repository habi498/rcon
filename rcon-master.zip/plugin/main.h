#ifndef MAIN_H
#define MAIN_H
#ifdef WIN32
#include <winsock2.h>
#else
#include <sys/socket.h>
#include <string.h>
#endif
#include "PluginAPI.h"
#include "SQImports.h"
#include "stdio.h"
#include "ReadCFG.h"
#include "string.h"
#include "hook.h"
#include "command.h"

#endif

